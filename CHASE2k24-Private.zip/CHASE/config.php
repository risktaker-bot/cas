<?php 



$bot = "your-token";
$chat_id = "chatid";


?>